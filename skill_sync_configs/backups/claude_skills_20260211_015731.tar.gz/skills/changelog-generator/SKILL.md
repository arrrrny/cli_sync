---
name: changelog-generator
description: Use when generating CHANGELOG.md from git commits - requires semantic analysis of actual file changes, categorization by feature/fix/chore, and proper version formatting. NOT for manual changelog writing or simple commit listing.
---

# CHANGELOG Generator Skill

## Overview

Automatically generate `CHANGELOG.md` by analyzing git commits and actual file changes. Uses semantic understanding to categorize changes (features, fixes, breaking changes, chores) and formats output according to Keep a Changelog standards.

**Core principle:** Analyze actual code changes, not just commit messages. Categorize semantically based on what files changed and what the changes did.

## When to Use

```dot
digraph when_to_use {
    "Need to update CHANGELOG?" [shape=diamond];
    "Have git commits to analyze?" [shape=diamond];
    "Need semantic categorization?" [shape=diamond];
    "Use CHANGELOG Generator" [shape=box];
    "Write manually" [shape=box];

    "Need to update CHANGELOG?" -> "Have git commits to analyze?";
    "Have git commits to analyze?" -> "Need semantic categorization?";
    "Need semantic categorization?" -> "Use CHANGELOG Generator" [label="yes"];
    "Have git commits to analyze?" -> "Write manually" [label="no"];
    "Need semantic categorization?" -> "Write manually" [label="no (simple list)"];
}
```

**Use when:**
- Preparing release and need to document changes
- Multiple commits need to be categorized (features, fixes, breaking)
- Need to analyze actual file changes (not just commit messages)
- Want semantic understanding of what changed (API changes, new features, bug fixes)
- Generating version entries with proper formatting
- Converting conventional commits to CHANGELOG format

**Do NOT use when:**
- Writing simple changelog from scratch without git history
- Manual changelog for non-git projects
- Just listing commits without semantic analysis
- One or two trivial commits (write manually)

## Quick Reference

### Basic Usage

```bash
# Generate from last release tag to HEAD
changelog-generator --from-last-tag

# Generate from specific commit
changelog-generator --from abc123

# Generate for specific version
changelog-generator --version 2.5.0 --from v2.4.0
```

### Workflow

```bash
# 1. Generate CHANGELOG entry
changelog-generator --version 2.5.0 --from v2.4.0 > /tmp/new_changes.md

# 2. Review and edit if needed
# (manual review step)

# 3. Insert into CHANGELOG.md at top
# (manual insertion or use --update flag)
```

## Categorization Rules

### By Commit Type

| Commit Type | CHANGELOG Category | Example |
|-------------|-------------------|---------|
| `feat:` | ✨ Features | Added new user authentication |
| `fix:` | 🐛 Bug Fixes | Fixed login validation error |
| `BREAKING CHANGE:` | 💥 Breaking Changes | Removed deprecated API |
| `perf:` | ⚡ Performance | Improved query performance |
| `refactor:` | 🔧 Code Refactoring | Refactored data layer |
| `docs:` | 📚 Documentation | Updated API documentation |
| `test:` | ✅ Tests | Added unit tests for auth |
| `chore:` | 🔨 Chore | Updated dependencies |
| `ci:` | 👷 CI | Fixed GitHub Actions workflow |

### By File Changes (Semantic Analysis)

| Changed Files | Category | Rationale |
|--------------|----------|-----------|
| `lib/src/domain/**/*.dart` | Features/Refactoring | Domain layer changes |
| `lib/src/data/**/*.dart` | Features/Fixes | Data layer changes |
| `pubspec.yaml` | Chore | Dependency updates |
| `test/**/*_test.dart` | Tests | Test additions |
| `README.md`, `docs/**` | Documentation | Doc changes |
| `.github/workflows/*` | CI | CI/CD changes |
| Breaking API signatures | Breaking Changes | Public API changes |

## CHANGELOG Format

Follows [Keep a Changelog](https://keepachangelog.com/) format:

```markdown
## [2.5.0] - 2025-02-05

### ✨ Features

#### New Feature Name
- Added feature X that does Y
- Added sub-feature Z

### 🐛 Bug Fixes

- Fixed bug where X happened when Y (fixes #123)
- Fixed validation error in Z

### 💥 Breaking Changes

#### Removed Feature
- **Removed:** Old API method `deprecatedMethod()` - use `newMethod()` instead
- **Migration:** Update calls from `deprecatedMethod()` to `newMethod()`

### ⚡ Performance

- Improved query performance by 50% using caching

### 🔧 Code Refactoring

- Refactored data layer for better separation of concerns

### 📚 Documentation

- Updated README with new examples
- Added API documentation for feature X

### ✅ Tests

- Added unit tests for authentication flow
- Fixed flaky test in checkout process

### 🔨 Chore

- Updated dependencies to latest versions
- Fixed linting warnings
```

## Command Reference

| Flag | Description | Example |
|------|-------------|---------|
| `--version=<ver>` | Version number for entry | `--version=2.5.0` |
| `--from=<ref>` | Git ref to start from | `--from=v2.4.0` or `--from=abc123` |
| `--from-last-tag` | Use last git tag as start | `--from-last-tag` |
| `--to=<ref>` | Git ref to end at (default: HEAD) | `--to=HEAD` |
| `--output=<file>` | Output file (default: stdout) | `--output=CHANGELOG.md` |
| `--update` | Insert into existing CHANGELOG.md | `--update` |
| `--dry-run` | Show what would be generated | `--dry-run` |
| `--format=<fmt>` | Format: markdown, json (default: markdown) | `--format=json` |

## Semantic Analysis Process

### Step 1: Get Commits

```bash
git log v2.4.0..HEAD --pretty=format:"%H|%s|%b" --no-merges
```

### Step 2: Parse Conventional Commits

Extract:
- Type: `feat`, `fix`, `BREAKING CHANGE`, etc.
- Scope: `auth`, `data`, `ui`, etc.
- Subject: Commit message
- Body: Detailed description
- Breaking Change: Presence of `BREAKING CHANGE:` footer

### Step 3: Analyze File Changes

For each commit:
```bash
git show --stat --pretty="" abc123
```

Categorize based on:
- **Domain entities/models** → Features or Refactoring
- **Repository/DataSource** → Features or Fixes
- **UseCase** → Features or Refactoring
- **Presentation (View/Controller)** → Features
- **Tests** → Tests
- **Documentation** → Documentation
- **Config/deps** → Chore

### Step 4: Detect Breaking Changes

Breaking if:
- Public API signature changed (parameters, return types)
- Entity field removed or renamed
- Repository method removed or renamed
- UseCase removed or signature changed
- Configuration key removed
- Database schema changed

### Step 5: Group and Format

Group commits by category and scope. Generate markdown with proper sections and formatting.

## Implementation Pattern

```bash
#!/bin/bash

# CHANGELOG Generator Script

VERSION=$1
FROM_REF=$2

# Get commits
COMMITS=$(git log ${FROM_REF}..HEAD --pretty=format:"%H|%s|%b" --no-merges)

# Analyze and categorize
echo "## [${VERSION}] - $(date +%Y-%m-%d)"
echo ""

# Parse commits and group by type
# (actual implementation uses semantic analysis)

echo "### ✨ Features"
echo ""
# Features here

echo "### 🐛 Bug Fixes"
echo ""
# Fixes here

# ... other sections
```

## Common Mistakes

| Mistake | Fix |
|---------|-----|
| Only reading commit messages | Analyze actual file changes with `git show --stat` |
| Not categorizing semantically | Group by what changed, not just commit type |
| Missing breaking changes | Check for API signature changes in files |
| Wrong version format | Use semantic versioning: X.Y.Z |
| Missing date | Always include date: YYYY-MM-DD |
| No migration notes | Add migration instructions for breaking changes |
| Ignoring commit scope | Group by scope (auth, data, ui) for clarity |

## Troubleshooting

### No Commits Found
```bash
Error: No commits found between v2.4.0 and HEAD
```
**Fix:** Check git ref exists:
```bash
git tag -l | grep v2.4.0
git log v2.4.0..HEAD --oneline | head -5
```

### Wrong Categorization
Commit categorized as "chore" but should be "feature"?

**Fix:** Prioritize file changes over commit type:
- Domain/data layer changes → Feature
- Even if commit says `chore:` but changes entities → Feature

### Breaking Changes Not Detected
API changed but not listed as breaking?

**Fix:** Check actual file diffs:
```bash
git diff v2.4.0..HEAD -- lib/src/domain/repositories/
```
Look for removed/renamed methods or signature changes.

## Advanced Usage

### Custom Categories

```bash
# Custom category mapping
changelog-generator \
  --category "feat:🚀 New Features" \
  --category "fix:🐛 Bug Fixes" \
  --category "perf:⚡ Performance"
```

### Exclude Patterns

```bash
# Exclude specific commits
changelog-generator \
  --exclude "Merge pull request" \
  --exclude "Update README"
```

### Group by Scope

```bash
# Group features by scope
changelog-generator \
  --group-by-scope \
  --scopes "auth,data,ui,tests"
```

Output:
```markdown
### ✨ Features

#### auth
- Added JWT authentication
- Added refresh token flow

#### data
- Added caching layer
- Added remote data source

#### ui
- Added user profile page
```

## Best Practices

1. **Always use conventional commits** - Makes categorization automatic
2. **Write clear commit subjects** - 50 char limit, imperative mood
3. **Include breaking change footers** - `BREAKING CHANGE: description`
4. **Review generated changelog** - Auto-generation is 90% accurate, review for 10%
5. **Keep descriptions concise** - One line per change when possible
6. **Add issue references** - `(fixes #123)` for traceability
7. **Date your releases** - Always include release date
8. **Version with semver** - MAJOR.MINOR.PATCH format

## Integration with Release Workflow

### Pre-Release

```bash
# Run tests
flutter test

# Generate CHANGELOG entry
changelog-generator --version 2.5.0 --from-last-tag > /tmp/new_release.md

# Review and edit
nano /tmp/new_release.md

# Insert into CHANGELOG.md
# (manual or script)
```

### Tag Release

```bash
# Commit CHANGELOG
git add CHANGELOG.md
git commit -m "chore: update CHANGELOG for v2.5.0"

# Tag release
git tag -a v2.5.0 -m "Release v2.5.0"

# Push
git push origin main --tags
```

## Real-World Example

```bash
# Generate for Zuraffa v2.5.0
changelog-generator --version 2.5.0 --from v2.4.0
```

Output:
```markdown
## [2.5.0] - 2026-02-05

### ✨ New Features

#### Sync UseCase
- Added `SyncUseCase` domain entity for synchronous operations
- Added sync method generation support for UseCases
- Added method appender for extending existing repositories and datasources
- Added sync feature documentation with comprehensive examples
- Updated CLI commands reference with sync usage
- Updated MCP server with sync capabilities

### 🐛 Bug Fixes

- Fixed meta transitive dependency issue
- Updated Zorphy dependencies to fix build errors
```

**Key points:**
- Categorized by semantic analysis (SyncUseCase = feature)
- Grouped related commits (all sync-related changes together)
- Clear descriptions from commit messages
- Proper version and date format
